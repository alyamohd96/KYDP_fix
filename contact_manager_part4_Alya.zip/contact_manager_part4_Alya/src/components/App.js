import './App.css';
import React, {useState, useEffect} from 'react';
import Header from './Header';
import AddContact from './AddContact';
import ContactList from './ContactList';
import ContactDetail from './ContactDetail';
import DeleteContact from './DeleteContact';
import {v4 as uuid} from 'uuid';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom/cjs/react-router-dom.min';
import api from '../api/contacts';
import EditContact from './EditContact';

function App() {
  const LOCAL_STORAGE_KEY = "contacts";
  const [contacts, setContacts] = useState(JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY)) ?? []);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchResults, setSearchResults] = useState([]);

  // Retrieve contacts 
  const retrieveContacts = async () => {
    const response = await api.get("/contacts");
    return response.data;
  };
  
  const addContactHandler = async (contact) => {
    console.log(contact);
    const request = {
      id: uuid(),
      ...contact
    }

    const response = await api.post("/contacts", request);
    setContacts([...contacts, response.data]);
  };

  const removeContactHandler = async (id) => {
    await api.delete(`/contacts/${id}`);
    const newContactList = contacts.filter((contact) => contact.id !==id);
    setContacts(newContactList);
  };

  const updateContactHandler = async (contact) => {
    const response = await api.put(`/contacts/${contact.id}`, contact);
    const {id, name, email} = response.data;
    setContacts(contacts.map(contact => {
      return contact.id === id ? {...response.data } : contact ;
    }));
  };

  const searchHandler = (searchTerm) => {
    setSearchTerm(searchTerm);
    if (searchTerm !== "") {
      const newContactList = contacts.filter((contact) => {
        return Object.values(contact)
          .join(" ")
          .toLowerCase()
          .includes(searchTerm.toLowerCase());
      })
      setSearchResults(newContactList);
    }
    else {
      setSearchResults(contacts);
    }
  };

  useEffect(() => {
    const getAllContacts = async () => {
      const allContacts = await retrieveContacts();
      if (allContacts) setContacts(allContacts);
    }

    getAllContacts();

  }, []);

  return (
    <div className='ui container'>
      <Router>
        <Header />
        <Switch>
          {/** Route for Add Contact component*/}
          <Route 
            path="/add" 
            render={(props) => (
              <AddContact {...props} addContactHandler={addContactHandler} />
            )} 
          />
          
          {/** Route for Contact List component*/}
          <Route 
            path="/" 
            exact 
            render={(props) => (
              <ContactList {...props} contacts={searchTerm.length <1 ? contacts : searchResults} term={searchTerm} searchKeyword={searchHandler} />
            )}
          />

           {/** Route for Edit Contact component*/}
           <Route 
            path="/edit" 
            render={(props) => (
              <EditContact {...props} updateContactHandler={updateContactHandler} />
            )} 
          />

          {/** Route for Contact Detail component*/}
          <Route 
            path="/contact/:id" 
            exact 
            component={ContactDetail} 
          />

          {/** Route for Delete page*/}
          <Route 
            path="/delete/:id"
            exact
            render={(props) => (
              <DeleteContact {...props} deleteContact={removeContactHandler} />
            )}
          />
        </Switch>
      </Router>
      
    </div>
  );
}

export default App;
