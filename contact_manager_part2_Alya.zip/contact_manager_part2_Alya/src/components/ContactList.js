import React from "react";
import ContactCard from "./ContactCard";
import { Link } from "react-router-dom/cjs/react-router-dom.min";

const ContactList = (props) => {
    console.log(props);

    //destructure
    //const {id, } = pr

    // const deleteContactHandler = (id) => {
    //     props.deleteContact(id);
    //     this.props.history.push("/");
    // };

    const renderContactList = props.contacts.map((contact) => {
        return (
            <ContactCard 
                contact={contact} 
                //clickHandler={deleteContactHandler} 
                key={contact.id}/> ); 
        }
    );

    return (
        <div className="ui celled list">
            <h2>Contact List</h2>
            {renderContactList}
            <Link to="/add">
                <button className="ui basic button">
                    <i className="plus square icon"></i>
                    Add Contact
                </button>
            </Link>
        </div>
    );
};

export default ContactList